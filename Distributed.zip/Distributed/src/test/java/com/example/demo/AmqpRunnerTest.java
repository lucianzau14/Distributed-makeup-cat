package com.example.demo;

import static org.junit.Assert.*;

public class AmqpRunnerTest {

}